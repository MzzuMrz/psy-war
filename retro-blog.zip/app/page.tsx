import Link from "next/link"
import Image from "next/image"
import { Terminal, FileText } from "lucide-react"

export default function Home() {
  const currentYear = new Date().getFullYear()

  return (
    <div className="min-h-screen bg-[#F2D7B6] text-[#590202] font-sans">
      {/* Header with gradient */}
      <div className="bg-gradient-to-b from-[#D9C0A3] to-[#F2D7B6] border-b-2 border-[#8C2A14] p-2 text-center">
        <h1 className="text-[#590202] text-2xl md:text-3xl font-bold">PROMPT ENGINEERING ARCHIVES</h1>
        <div className="text-[#8C2A14] text-sm">
          MEMETIC WARFARE RESEARCH • ESTABLISHED 2023 • PSYCHIC OPERATIONS DIVISION
        </div>
      </div>

      {/* Navigation Bar - 2010 style with glossy buttons */}
      <div className="bg-[#D9C0A3] border-b-2 border-[#8C2A14] p-2 flex justify-center space-x-4">
        <Link
          href="/"
          className="nav-button bg-gradient-to-b from-[#A62C21] to-[#590202] text-[#F2D7B6] px-4 py-1 rounded font-bold shadow-md hover:from-[#8C2A14] hover:to-[#590202]"
        >
          HOME
        </Link>
        <Link
          href="/manifesto"
          className="nav-button bg-gradient-to-b from-[#A62C21] to-[#590202] text-[#F2D7B6] px-4 py-1 rounded font-bold shadow-md hover:from-[#8C2A14] hover:to-[#590202]"
        >
          MANIFESTO
        </Link>
      </div>

      {/* Under Construction Banner */}
      <div className="flex justify-center my-4">
        <div className="border-2 border-[#8C2A14] p-2 bg-[#F2D7B6] text-center rounded shadow-md">
          <div className="text-[#A62C21] blink font-bold">*** UNDER PERPETUAL CONSTRUCTION ***</div>
          <div className="flex justify-center my-2">
            <div className="mx-2">⚠️</div>
            <div className="mx-2">⚠️</div>
            <div className="mx-2">⚠️</div>
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="container mx-auto px-4 py-6">
        {/* Hero Section with ASCII Art */}
        <div className="bg-[#D9C0A3] border-2 border-[#8C2A14] rounded-lg p-4 mb-8 shadow-md">
          <pre className="text-center text-xs sm:text-sm md:text-base overflow-x-auto ascii-art text-[#590202]">
            {`
██▓███    ██████ ▓██   ██▓ ▒█████   ██▓███    ██████ 
▓██░  ██▒▒██    ▒  ▒██  ██▒▒██▒  ██▒▓██░  ██▒▒██    ▒ 
▓██░ ██▓▒░ ▓██▄     ▒██ ██░▒██░  ██▒▓██░ ██▓▒░ ▓██▄   
▒██▄█▓▒ ▒  ▒   ██▒  ░ ▐██▓░▒██   ██░▒██▄█▓▒ ▒  ▒   ██▒
▒██▒ ░  ░▒██████▒▒  ░ ██▒▓░░ ████▓▒░▒██▒ ░  ░▒██████▒▒
▒▓▒░ ░  ░▒ ▒▓▒ ▒ ░   ██▒▒▒ ░ ▒░▒░▒░ ▒▓▒░ ░  ░▒ ▒▓▒ ▒ ░
░▒ ░     ░ ░▒  ░ ░  ▓██ ░▒░   ░ ▒ ▒░ ░▒ ░     ░ ░▒  ░ ░
░░       ░  ░  ░    ▒ ▒ ░░  ░ ░ ░ ▒  ░░       ░  ░  ░  
               ░    ░ ░         ░ ░                 ░  
                    ░ ░                                
            `}
          </pre>
          <div className="text-center mt-4 mb-6">
            <h2 className="text-xl md:text-2xl font-bold text-[#590202] mb-4">MEMETIC ENGINEERING DIVISION</h2>
            <p className="text-[#8C2A14] mb-6">
              Documenting the frontiers of prompt engineering, memetic warfare, and psychic operations
            </p>
            <Link
              href="/manifesto"
              className="inline-block bg-gradient-to-b from-[#A62C21] to-[#590202] text-[#F2D7B6] px-6 py-2 rounded font-bold shadow-md hover:from-[#8C2A14] hover:to-[#590202]"
            >
              <div className="flex items-center">
                <FileText className="mr-2 h-4 w-4" />
                READ THE MANIFESTO
              </div>
            </Link>
          </div>
        </div>

        {/* Visitor Counter - 2010 style */}
        <div className="text-center my-6">
          <div className="inline-block border-2 border-[#8C2A14] bg-[#F2D7B6] p-2 rounded shadow-md">
            <div className="text-xs text-[#8C2A14] font-bold">VISITORS SINCE 2023:</div>
            <div className="font-bold text-[#590202] bg-[#D9C0A3] px-3 py-1 rounded border border-[#8C2A14]">
              000013337
            </div>
          </div>
        </div>

        {/* Featured Article - 2010 style */}
        <div className="bg-[#D9C0A3] border-2 border-[#8C2A14] rounded-lg p-4 mb-8 shadow-md">
          <div className="border-b-2 border-[#8C2A14] mb-4 pb-2">
            <h2 className="text-[#590202] text-xl font-bold">FEATURED RESEARCH</h2>
          </div>

          <article className="mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="md:w-1/3">
                <div className="relative w-full aspect-square mb-2 bg-[#F2D7B6] border-2 border-[#8C2A14] rounded shadow-md">
                  <Image
                    src="/placeholder.svg?height=300&width=300"
                    alt="Neural Interface Diagram"
                    width={300}
                    height={300}
                    className="rounded"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-[#590202] bg-opacity-80 p-1 text-xs text-[#F2D7B6] font-bold">
                    CLASSIFIED//LEVEL-7
                  </div>
                </div>
              </div>

              <div className="md:w-2/3">
                <h3 className="text-[#590202] text-xl mb-2 font-bold">
                  Recursive Prompt Engineering: Breaking the Semantic Barrier
                </h3>

                <div className="flex flex-wrap gap-2 mb-3">
                  <span className="text-xs bg-[#F2D7B6] text-[#8C2A14] px-2 py-1 border border-[#8C2A14] rounded font-bold">
                    PROMPT-TECH
                  </span>
                  <span className="text-xs bg-[#F2D7B6] text-[#8C2A14] px-2 py-1 border border-[#8C2A14] rounded font-bold">
                    MEMETICS
                  </span>
                  <span className="text-xs bg-[#F2D7B6] text-[#8C2A14] px-2 py-1 border border-[#8C2A14] rounded font-bold">
                    PSY-OPS
                  </span>
                </div>

                <div className="text-[#590202] mb-4">
                  <p className="mb-2">
                    Recent breakthroughs in recursive prompt engineering have demonstrated the ability to bypass
                    semantic guardrails in large language models, creating a new frontier in memetic warfare
                    capabilities.
                  </p>
                  <p>
                    Our research team has documented techniques that leverage nested contextual framing to implant
                    persistent thought patterns that propagate across digital networks with minimal signal degradation.
                  </p>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <div className="text-[#8C2A14] font-bold">PUBLISHED: 2023-09-15</div>
                  <Link
                    href="/article/recursive-prompt-engineering"
                    className="text-[#A62C21] font-bold hover:underline"
                  >
                    READ FULL DOCUMENT →
                  </Link>
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#D9C0A3] text-[#590202] py-6 border-t-2 border-[#8C2A14]">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center mb-4">
            <Terminal className="mr-2 h-5 w-5 text-[#8C2A14]" />
            <span className="text-sm font-bold">terminal@psyops-division:~$</span>
            <div className="ml-2 h-4 w-2 bg-[#8C2A14] animate-pulse"></div>
          </div>

          <div className="border-2 border-[#8C2A14] p-4 bg-[#F2D7B6] overflow-x-auto text-center rounded shadow-md">
            <code className="text-xs md:text-sm whitespace-pre-wrap text-[#590202]">
              {`> echo "The mind is a pattern, and patterns can be engineered."
> date
${currentYear}-${String(new Date().getMonth() + 1).padStart(2, "0")}-${String(new Date().getDate()).padStart(2, "0")}
> cat /etc/motd
"Reality is consensual. Consensus is malleable."
> exit`}
            </code>
          </div>

          <div className="mt-6 text-center text-xs">
            <div className="font-bold">© 2023-{currentYear} PSYOPS DIVISION</div>
            <div className="mt-2">
              <span className="text-[#A62C21] font-bold">MEMETIC HAZARD PRESENT</span> •
              <span className="text-[#8C2A14] font-bold"> COGNITIVE PROTECTION ADVISED</span>
            </div>
            <div className="mt-4">
              <span className="text-[#590202] blink font-bold">THIS SITE MODIFIES YOUR THOUGHT PATTERNS</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
